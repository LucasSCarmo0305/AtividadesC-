﻿using System.Globalization;

Console.Write("Digite o sexo (M ou F): ");
char sexo = char.ToUpper(Console.ReadLine()[0]);

Console.Write("Digite a altura (em metros): ");
double altura;
while (!double.TryParse(Console.ReadLine(), NumberStyles.Any, CultureInfo.InvariantCulture, out altura))
{
    Console.Write("Entrada inválida! Digite a altura em metros (exemplo: 1.75): ");
}

double pesoIdeal;

if (sexo == 'M')
{
    pesoIdeal = 72.7 * altura - 58;
}
else if (sexo == 'F')
{
    pesoIdeal = 62.1 * altura - 44.7;
}
else
{
    Console.WriteLine("Sexo inválido! Use M ou F.");
    return;
}

Console.WriteLine($"O peso ideal é: {pesoIdeal:F2} kg");
