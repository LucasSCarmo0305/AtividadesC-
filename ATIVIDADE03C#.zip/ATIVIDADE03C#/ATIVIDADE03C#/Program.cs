﻿using System;

class Atividade03
{
    public static void Main()
    {
        Console.Write("Digite o salário do funcionário: ");
        double salarioB = double.Parse(Console.ReadLine());

        double calculo = salarioB * 0.98;

        Console.WriteLine("Salário a receber: R$ " + calculo);
    }
}
