﻿string maisVelho = "";
int idadeMaisVelho = 0, somaIdades = 0;

for (int i = 0; i < 5; i++)
{
    Console.Write("Nome: ");
    string nome = Console.ReadLine();
    Console.Write("Idade: ");
    int idade = int.Parse(Console.ReadLine());

    somaIdades += idade;

    if (idade > idadeMaisVelho)
    {
        idadeMaisVelho = idade;
        maisVelho = nome;
    }
}

double media = somaIdades / 5.0;
Console.WriteLine($"Idade média: {media:F1}");
Console.WriteLine($"Pessoa mais velha: {maisVelho} com {idadeMaisVelho} anos.");

