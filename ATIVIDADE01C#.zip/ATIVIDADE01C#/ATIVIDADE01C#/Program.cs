﻿using System;

class Atividade01
{
    public static void Main()
    {
        Console.WriteLine("Olá Mundo!");
        Console.Write("Qual seu nome? ");
        string nome = Console.ReadLine();

        Console.Write("Digite o ano de Nascimento: ");
        int nascimento = int.Parse(Console.ReadLine());

        int cal = 2050 - nascimento;
        Console.WriteLine("Bom dia " + nome + ", sua idade em 2050 é " + cal);
    }
}

