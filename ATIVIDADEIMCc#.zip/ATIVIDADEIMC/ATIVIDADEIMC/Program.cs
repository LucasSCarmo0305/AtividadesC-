﻿using System;


class AtividadeIMC
{
    public static void Main()
    {
        Console.WriteLine("Digite o seu nome:");
        string nome = Console.ReadLine();

        Console.WriteLine("Digite o seu sexo (M ou F):");
        string sexo = Console.ReadLine().Trim().ToUpper();

        Console.WriteLine("Digite o seu peso (kg):");
        double peso = double.Parse(Console.ReadLine());

        Console.WriteLine("Digite sua altura (m):");
        double altura = double.Parse(Console.ReadLine());

        double IMC = peso / (altura * altura);
        Console.WriteLine($"\n{nome}, seu IMC é {IMC:F2}");

      
        if (sexo == "M")
        {
            if (IMC < 20.7)
                Console.WriteLine("Abaixo do peso");
            else if (IMC <= 26.4)
                Console.WriteLine("No peso normal");
            else if (IMC <= 27.8)
                Console.WriteLine("Marginalmente acima do peso");
            else if (IMC <= 31.1)
                Console.WriteLine("Acima do peso ideal");
            else
                Console.WriteLine("Obeso");
        }
        else if (sexo == "F")
        {
            if (IMC < 19.1)
                Console.WriteLine("Abaixo do peso");
            else if (IMC <= 25.8)
                Console.WriteLine("No peso normal");
            else if (IMC <= 27.3)
                Console.WriteLine("Marginalmente acima do peso");
            else if (IMC <= 32.3)
                Console.WriteLine("Acima do peso ideal");
            else
                Console.WriteLine("Obeso");
        }
        else
        {
            Console.WriteLine("Sexo inválido. Use 'M' ou 'F'.");
        }
    }
}
