﻿class Atividade06
{
    public static void Main()
    {

        Console.Write("Digite o primeiro valor: ");
        double valor1 = double.Parse(Console.ReadLine());

        Console.Write("Digite o segundo valor: ");
        double valor2 = double.Parse(Console.ReadLine());

        Console.Write("Digite o terceiro valor: ");
        double valor3 = double.Parse(Console.ReadLine());


        double media = (valor1 + valor2 + valor3) / 3;

        

        if (valor1 > media)
        {
            Console.WriteLine("O valor1:" + valor1 + " é maior que a média");
        }
        if (valor2 > media)
        {
            Console.WriteLine("O valor2:" + valor2 + " é maior que a média");
        }
        if (valor3 > media)
        {
            Console.WriteLine("O valor3:" + valor3 + " é maior que a média");
        }

        if (valor1 <= media && valor2 <= media && valor3 <= media)
            Console.WriteLine("Nenhum valor é maior que a média.");

    }
}