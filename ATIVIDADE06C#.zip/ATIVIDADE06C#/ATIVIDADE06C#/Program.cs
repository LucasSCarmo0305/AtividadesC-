﻿class Atividade06
{
    public static void Main()
    {

        Console.Write("Digite um valor: ");
        int num = int.Parse(Console.ReadLine());

        if (num > 0)

        {
            Console.WriteLine("O valor e POSITIVO!");
        }
        else if (num == 0 )
        {
            Console.WriteLine("O valor e NEUTRO!");
        }
        else
        {
            Console.WriteLine("o valor e NEGATIVO!");

        }
    }
}