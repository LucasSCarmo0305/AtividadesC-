﻿class Atividade04
{
    public static void Main()
    {

        Console.Write("Digite o primeiro valor: ");
        double valor1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o segundo valor: ");
        double valor2 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o terceiro valor: ");
        double valor3 = Convert.ToDouble(Console.ReadLine());


        int peso1 = 3;
        int peso2 = 3;
        int peso3 = 4;

        double mediaP = (valor1 * 3 + valor2 * 3 + valor3 * 4) / (3 + 3 + 4);

        Console.WriteLine($" A média ponderada é:{mediaP}");
    }

}