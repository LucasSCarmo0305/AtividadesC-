﻿double maiorAltura = 0, menorAltura = double.MaxValue;
double somaAlturaMulheres = 0, somaAlturaGeral = 0;
int totalHomens = 0, totalMulheres = 0;

for (int i = 0; i < 7; i++)
{
    Console.Write("Sexo (m/f): ");
    char sexo = char.Parse(Console.ReadLine().ToLower());
    Console.Write("Altura (em metros): ");
    double altura = double.Parse(Console.ReadLine());

    if (altura > maiorAltura)
        maiorAltura = altura;
    if (altura < menorAltura)
        menorAltura = altura;

    somaAlturaGeral += altura;

    if (sexo == 'f')
    {
        somaAlturaMulheres += altura;
        totalMulheres++;
    }
    else if (sexo == 'm')
        totalHomens++;
}

Console.WriteLine($"Maior altura: {maiorAltura:F2} m");
Console.WriteLine($"Menor altura: {menorAltura:F2} m");
Console.WriteLine($"Média altura das mulheres: {(totalMulheres > 0 ? somaAlturaMulheres / totalMulheres : 0):F2} m");
Console.WriteLine($"Média altura geral: {somaAlturaGeral / 7:F2} m");
Console.WriteLine($"Total de homens: {totalHomens}");