﻿Console.Write("Nome do aluno: ");
string nome = Console.ReadLine();
Console.Write("Nota 1: ");
double n1 = double.Parse(Console.ReadLine());
Console.Write("Nota 2: ");
double n2 = double.Parse(Console.ReadLine());
Console.Write("Nota 3: ");
double n3 = double.Parse(Console.ReadLine());
Console.Write("Número de faltas: ");
int faltas = int.Parse(Console.ReadLine());

double media = (n1 + n2 + n3) / 3;

if (faltas > 27)
    Console.WriteLine("Reprovado por Falta.");
else if (media < 5.0)
    Console.WriteLine("Reprovado por Média.");
else
    Console.WriteLine("Aprovado.");