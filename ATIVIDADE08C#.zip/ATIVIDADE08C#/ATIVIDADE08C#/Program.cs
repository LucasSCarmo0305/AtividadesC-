﻿Console.Write("Digite o valor de a: ");
double a = double.Parse(Console.ReadLine());
Console.Write("Digite o valor de b: ");
double b = double.Parse(Console.ReadLine());
Console.Write("Digite o valor de c: ");
double c = double.Parse(Console.ReadLine());

double delta = b * b - 4 * a * c;

if (delta < 0)
    Console.WriteLine("A equação não possui raízes reais.");
else if (delta == 0)
    Console.WriteLine("A equação possui uma raiz real.");
else
    Console.WriteLine("A equação possui duas raízes reais.");
