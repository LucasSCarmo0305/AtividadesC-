﻿int[] vetor = new int[40];
int pares = 0;

for (int i = 0; i < 40; i++)
{
    Console.Write($"Valor na posição {i}: ");
    vetor[i] = int.Parse(Console.ReadLine());
    if (vetor[i] % 2 == 0)
        pares++;
}

Console.WriteLine($"Quantidade de números pares: {pares}");