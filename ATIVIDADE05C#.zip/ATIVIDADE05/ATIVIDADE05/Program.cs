﻿class Atividade05
{

    public static void Main()
    {

        Console.Write("Digite a temperatura em graus fahrenheit: ");
        int Fa = int.Parse(Console.ReadLine());

        double c = 5.0 / 9.0 * (Fa - 32);

        Console.WriteLine("O valor em Graus Centigrados:" + c);


    }

}