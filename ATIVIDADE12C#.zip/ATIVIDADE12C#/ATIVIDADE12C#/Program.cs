﻿double areaTotal = 0;

while (true)
{
    Console.Write("Nome do cômodo: ");
    string nome = Console.ReadLine();
    Console.Write("Largura (m): ");
    double largura = double.Parse(Console.ReadLine());
    Console.Write("Comprimento (m): ");
    double comprimento = double.Parse(Console.ReadLine());

    double area = largura * comprimento;
    Console.WriteLine($"Área do {nome}: {area:F2} m²");

    areaTotal += area;

    Console.Write("Deseja continuar? (sim/não): ");
    string continuar = Console.ReadLine().ToLower();
    if (continuar == "não")
        break;
}

Console.WriteLine($"Área total da residência: {areaTotal:F2} m²");