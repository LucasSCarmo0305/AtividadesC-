﻿
int[] vetor = new int[20];

for (int i = 0; i < 20; i++)
{
    Console.Write($"Digite o valor na posição {i}: ");
    vetor[i] = int.Parse(Console.ReadLine());
}

Console.Write("Digite o valor X a ser buscado: ");
int x = int.Parse(Console.ReadLine());

bool encontrado = false;
for (int i = 0; i < 20; i++)
{
    if (vetor[i] == x)
    {
        Console.WriteLine($"Valor {x} encontrado na posição {i}.");
        encontrado = true;
        break;
    }
}

if (!encontrado)
    Console.WriteLine("Valor não encontrado.");