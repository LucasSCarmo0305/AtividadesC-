﻿int[] vetor = new int[16];

for (int i = 0; i < 16; i++)
{
    Console.Write($"Valor na posição {i}: ");
    vetor[i] = int.Parse(Console.ReadLine());
}

for (int i = 0; i < 8; i++)
{
    int temp = vetor[i];
    vetor[i] = vetor[i + 8];
    vetor[i + 8] = temp;
}

Console.WriteLine("Vetor trocado:");
foreach (int val in vetor)
    Console.Write(val + " ");