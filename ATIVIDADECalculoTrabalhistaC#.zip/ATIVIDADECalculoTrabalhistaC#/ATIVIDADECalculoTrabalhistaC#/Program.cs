﻿using System;
using System.Collections.Generic;

class CalculoTrabalhista
{
    static void Main()
    {
        while (true)
        {
            Console.Write("Digite o Valor da hora (ou 0 para sair): ");
            double valorHora = double.Parse(Console.ReadLine());

            if (valorHora == 0)
            {
                Console.WriteLine("Sistema finalizado.");
                break;
            }

            Console.Write("Digite as Horas trabalhadas: ");
            int horas = int.Parse(Console.ReadLine());

            Console.Write("Possui vale transporte? (S/N): ");
            string valeT = Console.ReadLine().ToUpper();

            Console.Write("Digite o valor de outras deduções: ");
            double outrasDeducoes = double.Parse(Console.ReadLine());

            double salarioBruto = valorHora * horas;

            double inss1 = 0, inss2 = 0, inss3 = 0, inss4 = 0, descontoINSS = 0;

            if (salarioBruto <= 1320.00)
            {
                inss1 = salarioBruto * 0.075;
            }
            else if (salarioBruto <= 2571.29)
            {
                inss1 = 1320.00 * 0.075;
                inss2 = (salarioBruto - 1320.00) * 0.09;
            }
            else if (salarioBruto <= 3856.94)
            {
                inss1 = 1320.00 * 0.075;
                inss2 = (2571.29 - 1320.00) * 0.09;
                inss3 = (salarioBruto - 2571.29) * 0.12;
            }
            else if (salarioBruto <= 7507.49)
            {
                inss1 = 1320.00 * 0.075;
                inss2 = (2571.29 - 1320.00) * 0.09;
                inss3 = (3856.94 - 2571.29) * 0.12;
                inss4 = (salarioBruto - 3856.94) * 0.14;
            }
            else
            {
                inss1 = 1320.00 * 0.075;
                inss2 = (2571.29 - 1320.00) * 0.09;
                inss3 = (3856.94 - 2571.29) * 0.12;
                inss4 = (7507.49 - 3856.94) * 0.14;
            }

            descontoINSS = inss1 + inss2 + inss3 + inss4;

            double descontoVT = 0;
            if (valeT == "S")
            {
                descontoVT = salarioBruto * 0.06;
            }

            double baseIR = salarioBruto - descontoINSS;
            double descontoIRPF = 0;

            if (baseIR <= 2112.00)
            {
                descontoIRPF = 0;
            }
            else if (baseIR <= 2826.65)
            {
                descontoIRPF = (baseIR * 0.075) - 158.40;
            }
            else if (baseIR <= 3751.06)
            {
                descontoIRPF = (baseIR * 0.15) - 370.40;
            }
            else if (baseIR <= 4664.68)
            {
                descontoIRPF = (baseIR * 0.225) - 651.73;
            }
            else
            {
                descontoIRPF = (baseIR * 0.275) - 884.96;
            }

            if (descontoIRPF < 0)
            {
                descontoIRPF = 0;
            }

            double salarioLiquido = salarioBruto - descontoINSS - descontoIRPF - descontoVT - outrasDeducoes;

            Console.WriteLine("\n--- CÁLCULO TRABALHISTA ---");
            Console.WriteLine($"Salário Bruto: R$ {salarioBruto:F2}");
            Console.WriteLine($"Desconto INSS: - R$ {descontoINSS:F2}");
            Console.WriteLine($"Desconto IRPF: - R$ {descontoIRPF:F2}");
            Console.WriteLine($"Desconto Vale Transporte: - R$ {descontoVT:F2}");
            Console.WriteLine($"Outras Deduções: - R$ {outrasDeducoes:F2}");
            Console.WriteLine($"Salário Líquido: R$ {salarioLiquido:F2}");
            Console.WriteLine("------------------------------\n");
        }
    }
}
