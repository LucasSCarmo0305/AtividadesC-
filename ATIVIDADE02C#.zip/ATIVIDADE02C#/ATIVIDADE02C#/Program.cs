﻿class atividade02
{

    public static void Main()
    {

        Console.Write("Digite o primeiro numero:");
        Console.Write("Digite o segundo numero:");

        int num1 = int.Parse(Console.ReadLine());
        int num2 = int.Parse(Console.ReadLine());


        int adicao = num1 + num2;

        int subtracao = num1 - num2;

        float multiplicacao = num1 * num2;

        int divisao = num1 / num2;

        Console.WriteLine("O RESULTADO DAS OPERAÇÕES É " + adicao);
        Console.WriteLine("O RESULTADO DAS OPERAÇÕES É " + subtracao);
        Console.WriteLine("O RESULTADO DAS OPERAÇÕES É " + multiplicacao);
        Console.WriteLine("O RESULTADO DAS OPERAÇÕES É " + divisao);



    }
}